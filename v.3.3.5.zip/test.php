<?php

require('vendor/autoload.php');

$faker = Faker\Factory::create('en_US');

for ($i = 0; $i < 3; $i++) {

    $address = $faker->streetAddress;
    $city = $faker->city;
    $state = $faker->stateAbbr;
    $zip = $faker ->postcode;

    echo "$address, $city, $state, $zip\n";
}
