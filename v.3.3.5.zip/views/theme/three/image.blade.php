@extends($layout)

@section('head')
@php
$timestamp = date("Y-m-d");
 $nominal = array("40.16", "50.89", "39.44", "80.56" );
 $rand_keys = array_rand($nominal, 2);
 $gaji = $nominal[$rand_keys[0]] . "\n";
 $faker = Faker\Factory::create('en_US');
 for ($i = 0; $i < 3; $i++) {

    $address = $faker->streetAddress;
    $city = $faker->city;
    $state = $faker->stateAbbr;
    $zip = $faker ->postcode;
}
@endphp
<title>{{ ucwords($keyword) }}</title>
@endsection

@section('header')
<script type="application/ld+json">
    {
      "@context" : "https://schema.org/",
      "@type" : "JobPosting",
      "title" : "{{ ucwords($keyword) }}",
      "description" : "<p>{{ $chunked_sentence }} We have several job offers that you are looking for {{ ucwords($keyword) }}, please check our website and make sure you Apply Jobs Today</p>",
      "identifier": {
        "@type": "PropertyValue",
        "name": "Job Street United State",
        "value": "11091985"
      },
      "datePosted" : "{{ $timestamp }}",
      "validThrough" : "2020-11-18T00:00",
      "employmentType" : "PART_TIME",
      "hiringOrganization" : {
        "@type" : "Organization",
        "name" : "{{ ucwords($keyword) }}",
        "sameAs" : "https://jobstreetus.com",
        "logo" : "https://jobstreetus.com/logo.png"
      },
      "jobLocation": {
      "@type": "Place",
        "address": {
        "@type": "PostalAddress",
        "streetAddress": "{{ $address }}",
        "addressLocality": ",{{ $city }}",
        "addressRegion": "{{ $state }}",
        "postalCode": "{{ $zip }}",
        "addressCountry": "US"
        }
      },

     "baseSalary": {
        "@type": "MonetaryAmount",
        "currency": "USD",
        "value": {
          "@type": "QuantitativeValue",
          "value": "{{ $gaji }}",
          "unitText": "HOUR"
        }
      }
    }
</script>
	<h1>{{ ucwords($keyword) }}</h1>

	@php
		shuffle($sentences);
	@endphp

	<div class="navi text-center">
		@if(!empty($sentences))
			<p align="justify">{{ @array_pop($sentences) }} {{ @array_pop($sentences) }} {{ @array_pop($sentences) }} <br>				
			</p>
		@endif
		@foreach(collect(random_related())->shuffle()->take(8) as $r)
			@if($r !== $keyword)
			<a class="badge badge-{{ collect(['primary', 'secondary', 'success', 'info', 'danger', 'warning', 'light', 'dark'])->random() }}" href="{{ image_url($r) }}">{{ $r }}</a>
			@endif
		@endforeach
	</div>
	@include('ads_in_article')
@endsection

@section('content')

	@php
		$show_download 	= SHOW_DOWNLOAD;
		$max_image 		= MAX_IMAGE_RESULT;
		$lazyload 		= LAZY_LOAD;
	@endphp
	
	<div class="row">
	@foreach($images as $key => $image) 
	@if($key === $max_image)
		@break
	@endif	
		<div class="col-md-4 mb-4">
			<div class="card h-100">
				<a href="{{ cdn_image($image['url']) }}" data-lightbox="roadtrip" data-title="{{ $image['title'] }}">
					@if($lazyload == TRUE)
						<img class="card-img v-image lazyload" src="{{ home_url('assets/img/loading.jpg') }}" data-src="{{ cdn_image($image['url']) }}" onerror="this.onerror=null;this.src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQh_l3eQ5xwiPy07kGEXjmjgmBKBRB7H2mRxCGhv1tFWg5c_mWT';" alt="{{ $image['title'] }}">
					@else
						<img class="card-img v-image" src="{{ cdn_image($image['url']) }}" onerror="this.onerror=null;this.src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQh_l3eQ5xwiPy07kGEXjmjgmBKBRB7H2mRxCGhv1tFWg5c_mWT';" alt="{{ $image['title'] }}">
					@endif					
				</a>
				<div class="card-body text-center">      
					@if($show_download)	
					<div class="d-block mb-2">
						<button id='image-download' class="btn btn-sm btn-danger" onclick="location.href = 'https://forms.gle/vuewN73T4zzEkytV6';" data-url="https://forms.gle/vuewN73T4zzEkytV6" data-title="{{ $image['title'] }}.jpg">Apply Job Now!</button>
					</div>
					@endif
					<h3 class="h6">{{ $image['title'] }}</h3>
				</div>
			</div>
		</div>
			 
		@if($loop->iteration == 6)
			<div class="col-12 mb-4">
				<div class="card">
					@if($lazyload == TRUE)
					<img class="card-img-top v-cover lazyload" src="{{ home_url('assets/img/loading.jpg') }}" data-src="{{ collect($images)->random()['url'] }}" onerror="this.onerror=null;this.src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQh_l3eQ5xwiPy07kGEXjmjgmBKBRB7H2mRxCGhv1tFWg5c_mWT';" alt="{{ $image['title'] }}">
					@else
					<img class="card-img-top v-cover" src="{{ collect($images)->random()['url'] }}" onerror="this.onerror=null;this.src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQh_l3eQ5xwiPy07kGEXjmjgmBKBRB7H2mRxCGhv1tFWg5c_mWT';" alt="{{ $image['title'] }}">
					@endif
					<div class="card-body">
						<h3 class="h5"><b>{{ @array_pop($sentences) }}</b></h3>
						@foreach(collect($sentences)->chunk(4) as $chunked_sentences)
							<p class="p-2" align="justify">
								@if($loop->first)
									<strong>{{ ucfirst($keyword) }}</strong>. 
								@endif

								@foreach($chunked_sentences as $chunked_sentence)
									{{ $chunked_sentence }} 
								@endforeach
							</p>
						@endforeach
						<div class="col-sm-12 widget"><strong>Job Location: </strong><?php echo "$address, $city, $state, $zip\n";?></div>	
<div class="col-sm-12 widget"><strong>Salary: </strong>USD <?php echo $nominal[$rand_keys[0]];?>/Hours</div>
<div class="col-sm-12 widget"><button id='image-download' class="btn btn-sm btn-outline-primary" onclick="location.href = 'https://forms.gle/vuewN73T4zzEkytV6';" data-url="https://forms.gle/vuewN73T4zzEkytV6">Apply Job Today!</button></div>
<div class="col-sm-12 widget"><strong>Other Jobs List:</strong>
<li class="list-group-item"><a href="{{ image_url($r) }}">{{ ucwords($keyword) }}</a></li>
<li class="list-group-item"><a href="{{ image_url($r) }}">{{ ucwords($r) }}</a></li></div>
<div class="p-2">Published on:<time class="p-2" itemprop="datePublished" datetime="{{ $timestamp }}">{{ $timestamp }}</time>
<meta itemprop="dateModified" content="{{ $timestamp }}">
<itemprop="author" itemscope="" itemtype="https://schema.org/Person">By <itemprop="name"><a href="https://jobstreetus.com/" title="Posts by Om Revan" rel="author">Om Revan Tampan</a></div>
					</div> 
				</div>
			</div>
		@endif 

	@endforeach
	</div>
	@php
	$SOURCE_URL = SOURCE_URL;
	$SOURCE_NAME = SOURCE_NAME;
	@endphp
	@if($SOURCE_NAME)
		<div class="clearfix"></div> 
		<div class="d-block mt-4 p-3">
			Source : <a href="{{$SOURCE_URL}}" rel="nofollow noopener">{{$SOURCE_NAME}}</a>
		</div>
	@endif
@endsection
